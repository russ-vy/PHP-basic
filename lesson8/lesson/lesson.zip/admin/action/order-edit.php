<?php

if (isset($_POST)){
    var_dump($_POST);
    die();
}


$post = checkform(json_decode($_POST['order']));
extract($post);

$q = "
    update ordered
    set
        phone = '$phone'
        ,address = '$address'
        ,id_status = $id_status
    where id = $id
";
dbquery($q);

echo json_encode(["message" => "Изменения сохранены !"]);
return;
