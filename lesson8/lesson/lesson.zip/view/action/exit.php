<?php

$_SESSION = [];

header("Location: /");
return;